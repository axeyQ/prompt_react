const BfRotating = () => {
    return ( 
        <div className="bf-card">
  <div className="bf-card-inner">
    <div className="bf-card-front">
      <p>Front Side</p>
    </div>
    <div class="bf-card-back">
      <p>Back Side</p>
    </div>
            </div>
        </div>

    );
}
 
export default BfRotating;