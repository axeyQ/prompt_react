export type Feature = {
    avatar: string;
    title: string;
    description: string;
    variant: string;
    containerClass: string;
}
