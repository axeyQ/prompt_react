import PricingCards1 from './PricingCards1';
import PricingCards2 from './PricingCards2';

export { PricingCards1, PricingCards2 };
export * from './types';