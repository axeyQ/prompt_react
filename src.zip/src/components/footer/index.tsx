import Footer1 from './Footer1';


export { Footer1 };
