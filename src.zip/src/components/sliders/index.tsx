import SwiperSlider1 from './SwiperSlider1';
import SwiperSlider2 from './SwiperSlider2';
import SwiperSlider3 from './SwiperSlider3';
import SwiperSlider4 from './SwiperSlider4';

export { SwiperSlider1, SwiperSlider2, SwiperSlider3, SwiperSlider4 };
